#include <RcppArmadillo.h>
using namespace Rcpp;
using namespace arma;

// [[Rcpp::depends(RcppArmadillo)]]

//' @title Compute Estimates for Linear Regression with Rcpp
//' @name fastlm
//' @description Return estimates for the fitted linear regression model
//' @param X predictor matrix
//' @param y output matrix
//' @param freqs weight assigned to data
//' @return list of estimates
//' @export
// [[Rcpp::export]]
List fastlm(const arma::mat& X, const arma::colvec& y, const arma::mat& freqs) {
  int n = X.n_rows, k = X.n_cols;

  arma::mat W = diagmat(freqs);     //weight matrice
  arma::colvec coef = arma::pinv(arma::trans(X)*W*X)*arma::trans(X)*W*y;     // my weighted coef

  arma::colvec res  = y - X*coef;           // residuals

  // std.errors of coefficients
  double s2 = as_scalar((arma::trans(res)*W*res)/(n - k));   //my weighted s2

  double std_err = sqrt(s2);    //my std

  return List::create(Named("coefficients") = coef,
                      Named("std.err") = std_err
                        );
}