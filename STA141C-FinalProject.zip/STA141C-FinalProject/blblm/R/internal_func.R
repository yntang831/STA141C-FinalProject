#' @name split_data
#' @title split_data
#' @param data data
#' @param m number of subsample to be splited into
#' split data into m parts of approximated equal sizes
split_data <- function(data, m) {
  idx <- sample.int(m, nrow(data), replace = TRUE)
  data %>% split(idx)
}



#' @name mean_lwr_upr
#' @title mean_lwr_upr
#' @param x data
#' @param level condidence level with a default of 0.95
mean_lwr_upr <- function(x, level = 0.95) {
  alpha <- 1 - level
  c(fit = mean(x), quantile(x, c(alpha / 2, 1 - alpha / 2)) %>% set_names(c("lwr", "upr")))
}



#' @name map_mean
#' @title map_mean
#' @param .x data
#' @param .f function to be applied to each data
#' @param ... additional arguments
map_mean <- function(.x, .f, ...) {
  (map(.x, .f, ...) %>% reduce(`+`)) / length(.x)
}



#' @name map_cbind
#' @title map_cbind
#' @param .x data
#' @param .f function to be applied to each data
#' @param ... additional arguments
map_cbind <- function(.x, .f, ...) {
  map(.x, .f, ...) %>% reduce(cbind)
}



#' @name map_rbind
#' @title map_rbind
#' @param .x data
#' @param .f function to be applied to each data
#' @param ... additional arguments
map_rbind <- function(.x, .f, ...) {
  map(.x, .f, ...) %>% reduce(rbind)
}
