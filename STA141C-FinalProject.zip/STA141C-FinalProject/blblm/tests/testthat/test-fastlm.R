test_that("fastlm works", {

  #define data
  data <- mtcars
  formula <- mpg ~ wt * hp
  n <- nrow(data)
  freqs <- rmultinom(1, n, rep(1, n))

  #fit lm from base r
  lm.fit <- lm(formula, data, weights = freqs)

  #fit my fastlm
  X <- model.matrix(reformulate(attr(terms(formula), "term.labels")), data)
  y <- model.matrix(reformulate(as.character(attr(terms(formula), "variables")[[2]])), data)[,-1]
  fastlm.fit <- fastlm(X,y, freqs)

  expect_equivalent(lm.fit$coefficients, fastlm.fit$coefficients)
})
