#' @name blbglm
#' @title Bag of Little Bootstrap for Logistic Regression Model
#' @param formula description of regression model to be fitted
#' @param data dataframe or list of filenames
#' @param m number of subsample with a default of 10
#' @param B number of bootstrap sample with a default of 5000
#' @param parallel logical vector with a default of FALSE
#' @return list of estimates and the formula of logistic regression model
#' @export
blbglm <- function(formula, data, m = 10, B = 5000, parallel = FALSE) {
  if (parallel == FALSE) {
    mapfunc <- map
  } else if (parallel == TRUE) {
    mapfunc = future_map
  } else (
    stop("'parallel' need to be a logical vector")
  )

  if (is.data.frame(data)) {
    data_list <- split_data(data, m)
    estimates <- mapfunc(
      data_list,
      ~ lm_each_subsample(formula = formula, data = ., n = nrow(data), B = B))
  } else if (is.character(data)) {
    row <- map(data, function(){
      length(vroom_lines(data, altrep_opts = TRUE, progress = FALSE)) - 1L
    })
    n = sum(row)
    estimates <- mapfunc(
      data,
      ~ {
        df <- read_csv(., col_types = cols())
        glm_each_subsample(formula = formula, data = df, n = n, B = B)
      })
  } else {
    stop("input has to be a dataframe or filenames")
  }

  res <- list(estimates = estimates, formula = formula)
  class(res) <- "blbglm"
  invisible(res)
}

#' @name glm_each_subsample
#' @title glm_each_subsample
#' @param formula description of regression model to be fitted
#' @param data data
#' @param n number of total data
#' @param B number of bootstrap sample
#' compute the estimates
glm_each_subsample <- function(formula, data, n, B) {
  replicate(B, glm_each_boot(formula, data, n), simplify = FALSE)
}

#' @name glm_each_boot
#' @title glm_each_boot
#' @param formula description of regression model to be fitted
#' @param data data
#' @param n number of total data
#' compute the regression estimates for a blbglm dataset
glm_each_boot <- function(formula, data, n) {
  freqs <- rmultinom(1, n, rep(1, nrow(data)))
  glm1(formula, data, freqs)
}

#' @name glm1
#' @title glm1
#' @param formula description of regression model to be fitted
#' @param data data
#' @param freqs weight assigned to each data
#' estimate the regression estimates based on given the number of repetitions
glm1 <- function(formula, data, freqs) {
  # drop the original closure of formula,
  # otherwise the formula will pick a wront variable from the global scope.
  environment(formula) <- environment()
  #y <- model.extract(object$model, "response")
  #data$y<-ifelse(data$y==sort(data$y[1]),1,0)
  object <- glm(formula, data, weights = freqs, family = binomial("logit"))
  list(coef = coef(object))
}


#' @name print.blbglm
#' @title print.blbglm
#' @title Print the Formula of blbglm
#' @param x the output of blbglm function
#' @param ... additional arguments
#' @return description of the fitted regression model
#' @export
#' @method print blbglm
print.blbglm <- function(x, ...) {
  cat("blbglm model:", capture.output(x$formula))
  cat("\n")
}


#' @name coef.blbglm
#' @title coef.blbglm
#' @title Compute the Coefficient Estimate of blbglm
#' @param object output from blbglm function
#' @param ... additional arguments
#' @return estimated beta of blbglm
#' @export
#' @method coef blbglm
coef.blbglm <- function(object, ...) {
  est <- object$estimates
  map_mean(est, ~ map_cbind(., "coef") %>% rowMeans())
}



#' @name confint.blbglm
#' @title confint.blbglm
#' @title Compute the Confidence Interval for Coefficient Estimates of blbglm
#' @param object output from blbglm function
#' @param parm variables of interest with a default of NULL
#' @param level confidence level with a default of 0.95
#' @param ... additional arguments
#' @return confidence interval for coeficient estimates of blbglm
#' @export
#' @method confint blbglm
confint.blbglm <- function(object, parm = NULL, level = 0.95, ...) {
  if (is.null(parm)) {
    parm <- attr(terms(object$formula), "term.labels")
  }
  alpha <- 1 - level
  est <- object$estimates
  out <- map_rbind(parm, function(p) {
    map_mean(est, ~ map_dbl(., list("coef", p)) %>% quantile(c(alpha / 2, 1 - alpha / 2)))
  })
  if (is.vector(out)) {
    out <- as.matrix(t(out))
  }
  dimnames(out)[[1]] <- parm
  out
}

#' @name predict.blbglm
#' @title predict.blbglm
#' @title Predict the Value of Output Variable with New Data Input given blbglm
#' @param object output from blbglm function
#' @param new_data dataframe
#' @param ... additional arguments
#' @return the probability of predicted response variable (or including its prediction interval)
#' @export
#' @method predict blbglm
predict.blbglm <- function(object, new_data, ...) {
  est <- object$estimates
  X <- model.matrix(reformulate(attr(terms(object$formula), "term.labels")), new_data)
    p <- map_mean(est, ~ map_cbind(., ~ X %*% .$coef) %>% rowMeans())
    exp(p)/(1+exp(p))
  }




