#' @import purrr
#' @import furrr
#' @import vroom
#' @import stats
#' @importFrom magrittr %>%
#' @importFrom utils capture.output
#' @aliases NULL
#' @details
#' Linear Regression with Little Bag of Bootstraps
"_PACKAGE"


## quiets concerns of R CMD check re: the .'s that appear in pipelines
# from https://github.com/jennybc/googlesheets/blob/master/R/googlesheets.R
utils::globalVariables(c("."))


#' @name blblm
#' @title Bag of Little Bootstrap for Linear Regression Model
#' @param formula description of regression model to be fitted
#' @param data dataframe or list of filenames
#' @param m number of subsample with a default of 10
#' @param B number of bootstrap sample with a default of 5000
#' @param parallel logical vector with a default of FALSE
#' @return list of estimates and the formula of linear regression model
#' @export
blblm <- function(formula, data, m = 10, B = 5000, parallel = FALSE) {
  if (parallel == FALSE) {
    mapfunc <- map
  } else if (parallel == TRUE) {
    mapfunc <- future_map
  } else (
    stop("'parallel' need to be a logical vector")
  )

  if (is.data.frame(data)) {
    data_list <- split_data(data, m)
    estimates <- mapfunc(
      data_list,
      ~ lm_each_subsample(formula = formula, data = ., n = nrow(data), B = B))
  } else if (is.character(data)) {
    row <- map(data, function(){
      length(vroom_lines(data, altrep_opts = TRUE, progress = FALSE)) - 1L
    })
    n = sum(row)
    estimates <- mapfunc(
      data,
      ~ {
        df <- read_csv(., col_types = cols())
        lm_each_subsample(formula = formula, data = df, n = n, B = B)
        })
  } else {
    stop("input has to be a dataframe or filenames")
  }
  res <- list(estimates = estimates, formula = formula)
  class(res) <- "blblm"
  invisible(res)
}


#' @name lm_each_subsample
#' @title lm_each_subsample
#' @param formula description of regression model to be fitted
#' @param data data
#' @param n number of total data
#' @param B number of bootstrap sample
#' compute the estimates
lm_each_subsample <- function(formula, data, n, B) {
  replicate(B, lm_each_boot(formula, data, n), simplify = FALSE)
}

#' @name lm_each_boot
#' @title lm_each_boot
#' @param formula description of regression model to be fitted
#' @param data data
#' @param n number of total data
#' compute the regression estimates for a blblm dataset
lm_each_boot <- function(formula, data, n) {
  freqs <- rmultinom(1, n, rep(1, nrow(data)))
  lm1(formula, data, freqs)
}


#' @name lm1
#' @title lm1
#' @param formula description of regression model to be fitted
#' @param data data
#' @param freqs weight assigned to each data
#' estimate the regression estimates based on given the number of repetitions
lm1 <- function(formula, data, freqs) {
  # drop the original closure of formula,
  # otherwise the formula will pick a wrong variable from the global scope.
  environment(formula) <- environment()
  X <- model.matrix(reformulate(attr(terms(formula), "term.labels")), data)
  y <- as.matrix(model.matrix(reformulate(as.character(attr(terms(formula), "variables")[[2]])), data)[,-1])
  fit <- fastlm(X, y, freqs)
  list(coef = as.vector(fit$coefficients), sigma = fit$std.err)
}


#' @name print.blblm
#' @title Print the Formula of blblm
#' @param x the output of blbglm function
#' @param ... additional arguments
#' @return description of the fitted regression model
#' @export
#' @method print blblm
print.blblm <- function(x, ...) {
  cat("blblm model:", capture.output(x$formula))
  cat("\n")
}


#' @name sigma.blblm
#' @title Compute the Error Variance of blblm
#' @param object output from blblm function
#' @param confidence logical vector with a default of FALSE
#' @param level confidence level with a default of 0.95
#' @param ... additional arguments
#' @return error variance of blblm (or including its confidence interval)
#' @export
#' @method sigma blblm
sigma.blblm <- function(object, confidence = FALSE, level = 0.95, ...) {
  est <- object$estimates
  sigma <- mean(map_dbl(est, ~ mean(map_dbl(., "sigma"))))
  if (confidence == TRUE) {
    alpha <- 1 - 0.95
    limits <- est %>%
      map_mean(~ quantile(map_dbl(., "sigma"), c(alpha / 2, 1 - alpha / 2))) %>%
      set_names(NULL)
    return(c(sigma = sigma, lwr = limits[1], upr = limits[2]))
  } else {
    return(sigma)
  }
}

#' @name coef.blblm
#' @title Compute the Coefficient Estimate of blblm
#' @param object output from blblm function
#' @param ... additional arguments
#' @return coefficient of blblm
#' @export
#' @method coef blblm
coef.blblm <- function(object, ...) {
  est <- object$estimates
  map_mean(est, ~ map_cbind(., "coef") %>% rowMeans())
}


#' @name confint.blblm
#' @title Compute the Confidence Interval for Coefficient Estimates of blblm
#' @param object output from blblm function
#' @param parm variables of interest with a default of NULL
#' @param level confidence level with a default of 0.95
#' @param ... additional arguments
#' @return confidence interval for coeficient estimates of blblm
#' @export
#' @method confint blblm
confint.blblm <- function(object, parm = NULL, level = 0.95, ...) {
  if (is.null(parm)) {
    parm <- attr(terms(object$formula), "term.labels")
  }
  alpha <- 1 - level
  est <- object$estimates
  out <- map_rbind(parm, function(p) {
    map_mean(est, ~ map_dbl(., list("coefficients", p)) %>% quantile(c(alpha / 2, 1 - alpha / 2)))
  })
  if (is.vector(out)) {
    out <- as.matrix(t(out))
  }
  dimnames(out)[[1]] <- parm
  out
}

#' @name predict.blblm
#' @title Predict the Value of Output Variable with New Data Input given blblm
#' @param object output from blblm function
#' @param new_data dataframe
#' @param confidence logical vector with a default of FALSE
#' @param level confidence level with a default of 0.95
#' @param ... additional arguments
#' @return the predicted output variable (or including its prediction interval)
#' @export
#' @method predict blblm
predict.blblm <- function(object, new_data, confidence = FALSE, level = 0.95, ...) {
  est <- object$estimates
  X <- model.matrix(reformulate(attr(terms(object$formula), "term.labels")), new_data)
  if (confidence == TRUE) {
    map_mean(est, ~ map_cbind(., ~ X %*% .$coef) %>%
      apply(1, mean_lwr_upr, level = level) %>%
      t())
  } else {
    map_mean(est, ~ map_cbind(., ~ X %*% .$coef) %>% rowMeans())
  }
}
